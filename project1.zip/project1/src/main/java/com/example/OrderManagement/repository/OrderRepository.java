package com.example.OrderManagement.repository;

import com.example.OrderManagement.model.Order;
import com.example.OrderManagement.model.Order.OrderStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    Page<Order> findByCreatedByUser_Id(Long userId, Pageable pageable);
    
    Page<Order> findAll(Pageable pageable);
    
    @Query("SELECT o FROM Order o WHERE o.createdByUser.id = :userId " +
           "AND (:status IS NULL OR o.status = :status) " +
           "AND (:startDate IS NULL OR o.createdAt >= :startDate) " +
           "AND (:endDate IS NULL OR o.createdAt <= :endDate)")
    Page<Order> findByCreatedByUserWithFilters(
            @Param("userId") Long userId,
            @Param("status") OrderStatus status,
            @Param("startDate") LocalDateTime startDate,
            @Param("endDate") LocalDateTime endDate,
            Pageable pageable
    );
    
    Optional<Order> findByIdAndCreatedByUser_Id(Long id, Long userId);
}

