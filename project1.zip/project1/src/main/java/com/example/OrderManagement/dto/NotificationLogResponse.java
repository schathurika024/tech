package com.example.OrderManagement.dto;

import com.example.OrderManagement.model.NotificationLog;

import java.time.LocalDateTime;

public class NotificationLogResponse {
    private Long id;
    private String eventType;
    private Long orderId;
    private String payload;
    private NotificationLog.NotificationStatus status;
    private LocalDateTime createdAt;

    public NotificationLogResponse(NotificationLog log) {
        this.id = log.getId();
        this.eventType = log.getEventType();
        this.orderId = log.getOrderId();
        this.payload = log.getPayload();
        this.status = log.getStatus();
        this.createdAt = log.getCreatedAt();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    public NotificationLog.NotificationStatus getStatus() {
        return status;
    }

    public void setStatus(NotificationLog.NotificationStatus status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}

