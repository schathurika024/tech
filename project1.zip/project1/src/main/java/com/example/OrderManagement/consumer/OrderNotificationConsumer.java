package com.example.OrderManagement.consumer;

import com.example.OrderManagement.dto.OrderCreatedEvent;
import com.example.OrderManagement.dto.OrderStatusChangedEvent;
import com.example.OrderManagement.model.NotificationLog;
import com.example.OrderManagement.repository.NotificationLogRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;

@Component
public class OrderNotificationConsumer {
    private static final Logger logger = LoggerFactory.getLogger(OrderNotificationConsumer.class);

    @Autowired
    private NotificationLogRepository notificationLogRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private JavaMailSender mailSender;

    @Value("${notification.email.from:no-reply@ordermanagement.local}")
    private String fromAddress;

    @RabbitListener(queues = "order.notifications")
    public void handleOrderNotification(Message message) {
        String body = null;
        try {
            // Extract the JSON body from the Message object
            body = new String(message.getBody(), StandardCharsets.UTF_8);
            logger.info("Received message: {}", body);
            
            // Parse JSON to determine event type
            JsonNode jsonNode = objectMapper.readTree(body);
            String eventType = jsonNode.has("eventType") ? jsonNode.get("eventType").asText() : null;
            
            if ("ORDER_CREATED".equals(eventType)) {
                OrderCreatedEvent event = objectMapper.readValue(body, OrderCreatedEvent.class);
                handleOrderCreated(event);
            } else if ("ORDER_STATUS_CHANGED".equals(eventType)) {
                OrderStatusChangedEvent event = objectMapper.readValue(body, OrderStatusChangedEvent.class);
                handleOrderStatusChanged(event);
            } else {
                logger.warn("Unknown event type: {}", eventType);
                saveNotificationLog("UNKNOWN", null, body, NotificationLog.NotificationStatus.FAILED);
            }
        } catch (Exception e) {
            logger.error("Error processing notification message", e);
            String payload = body;
            if (payload == null && message != null) {
                try {
                    payload = new String(message.getBody(), StandardCharsets.UTF_8);
                } catch (Exception ex) {
                    payload = "Failed to extract message body: " + ex.getMessage();
                }
            }
            if (payload == null) {
                payload = "Unknown message format";
            }
            saveNotificationLog("UNKNOWN", null, payload, NotificationLog.NotificationStatus.FAILED);
        }
    }

    private void handleOrderCreated(OrderCreatedEvent event) {
        try {
            logger.info("Processing ORDER_CREATED event for order {}", event.getOrderId());
            
            // Try to send email, but don't fail if mail server is unavailable
            try {
                logger.info("Attempting to send ORDER_CREATED email to {} for order {}", event.getCustomerEmail(), event.getOrderId());
                SimpleMailMessage mail = new SimpleMailMessage();
                mail.setFrom(fromAddress);
                mail.setTo(event.getCustomerEmail());
                mail.setSubject("Your order " + event.getOrderId() + " has been created");
                mail.setText(
                        "Hi,\n\n" +
                        "Your order " + event.getOrderId() + " has been created.\n" +
                        "Total amount: " + event.getTotalAmount() + "\n" +
                        "Created at: " + event.getCreatedAt() + "\n\n" +
                        "Thank you for your purchase."
                );
                mailSender.send(mail);
                logger.info("Email sent successfully to {}", event.getCustomerEmail());
            } catch (Exception emailException) {
                logger.warn("Failed to send email (mail server may not be configured): {}", emailException.getMessage());
                // Continue processing even if email fails
            }
            
            // Save notification log (always save, even if email fails)
            saveNotificationLog(
                    event.getEventType(),
                    event.getOrderId(),
                    objectMapper.writeValueAsString(event),
                    NotificationLog.NotificationStatus.SUCCESS
            );
            
            logger.info("Successfully processed ORDER_CREATED event for order {}", event.getOrderId());
        } catch (Exception e) {
            logger.error("Error handling ORDER_CREATED event", e);
            String payload = null;
            try {
                payload = objectMapper.writeValueAsString(event);
            } catch (Exception ex) {
                payload = String.valueOf(event);
            }
            saveNotificationLog("ORDER_CREATED", event.getOrderId(), payload, NotificationLog.NotificationStatus.FAILED);
        }
    }

    private void handleOrderStatusChanged(OrderStatusChangedEvent event) {
        try {
            logger.info("Processing ORDER_STATUS_CHANGED event for order {}: {} -> {}", 
                    event.getOrderId(), event.getOldStatus(), event.getNewStatus());

            // Try to send email, but don't fail if mail server is unavailable
            try {
                logger.info("Attempting to send ORDER_STATUS_CHANGED email for order {}", event.getOrderId());
                SimpleMailMessage mail = new SimpleMailMessage();
                mail.setFrom(fromAddress);
                // In a real system we might look up the customer email by orderId.
                // For now, send to a generic support address or configured recipient.
                mail.setTo(fromAddress);
                mail.setSubject("Order " + event.getOrderId() + " status changed");
                mail.setText(
                        "Order " + event.getOrderId() + " status has changed.\n" +
                        "Old status: " + event.getOldStatus() + "\n" +
                        "New status: " + event.getNewStatus() + "\n" +
                        "Updated at: " + event.getUpdatedAt()
                );
                mailSender.send(mail);
                logger.info("Email sent successfully for order status change");
            } catch (Exception emailException) {
                logger.warn("Failed to send email (mail server may not be configured): {}", emailException.getMessage());
                // Continue processing even if email fails
            }
            
            // Save notification log (always save, even if email fails)
            saveNotificationLog(
                    event.getEventType(),
                    event.getOrderId(),
                    objectMapper.writeValueAsString(event),
                    NotificationLog.NotificationStatus.SUCCESS
            );
            
            logger.info("Successfully processed ORDER_STATUS_CHANGED event for order {}", event.getOrderId());
        } catch (Exception e) {
            logger.error("Error handling ORDER_STATUS_CHANGED event", e);
            String payload = null;
            try {
                payload = objectMapper.writeValueAsString(event);
            } catch (Exception ex) {
                payload = String.valueOf(event);
            }
            saveNotificationLog("ORDER_STATUS_CHANGED", event.getOrderId(), payload, NotificationLog.NotificationStatus.FAILED);
        }
    }

    private void saveNotificationLog(String eventType, Long orderId, String payload, NotificationLog.NotificationStatus status) {
        try {
            NotificationLog log = new NotificationLog();
            log.setEventType(eventType);
            log.setOrderId(orderId);
            log.setPayload(payload);
            log.setStatus(status);
            notificationLogRepository.save(log);
        } catch (Exception e) {
            logger.error("Error saving notification log", e);
        }
    }
}

