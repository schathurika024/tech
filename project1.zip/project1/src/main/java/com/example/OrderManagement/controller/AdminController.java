package com.example.OrderManagement.controller;

import com.example.OrderManagement.dto.NotificationLogResponse;
import com.example.OrderManagement.dto.OrderResponse;
import com.example.OrderManagement.dto.UserResponse;
import com.example.OrderManagement.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {
    @Autowired
    private AdminService adminService;

    @GetMapping("/users")
    public ResponseEntity<Page<UserResponse>> getAllUsers(
            @PageableDefault(size = 20) Pageable pageable) {
        Page<UserResponse> users = adminService.getAllUsers(pageable);
        return ResponseEntity.ok(users);
    }

    @GetMapping("/orders")
    public ResponseEntity<Page<OrderResponse>> getAllOrders(
            @PageableDefault(size = 20) Pageable pageable) {
        Page<OrderResponse> orders = adminService.getAllOrders(pageable);
        return ResponseEntity.ok(orders);
    }

    @GetMapping("/notifications")
    public ResponseEntity<Page<NotificationLogResponse>> getAllNotifications(
            @PageableDefault(size = 20) Pageable pageable) {
        Page<NotificationLogResponse> notifications = adminService.getAllNotifications(pageable);
        return ResponseEntity.ok(notifications);
    }
}

