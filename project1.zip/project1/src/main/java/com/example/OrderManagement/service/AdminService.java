package com.example.OrderManagement.service;

import com.example.OrderManagement.dto.NotificationLogResponse;
import com.example.OrderManagement.dto.OrderResponse;
import com.example.OrderManagement.dto.UserResponse;
import com.example.OrderManagement.model.Order;
import com.example.OrderManagement.model.NotificationLog;
import com.example.OrderManagement.repository.NotificationLogRepository;
import com.example.OrderManagement.repository.OrderRepository;
import com.example.OrderManagement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class AdminService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private NotificationLogRepository notificationLogRepository;

    public Page<UserResponse> getAllUsers(Pageable pageable) {
        return userRepository.findAll(pageable)
                .map(UserResponse::new);
    }

    public Page<OrderResponse> getAllOrders(Pageable pageable) {
        return orderRepository.findAll(pageable)
                .map(OrderResponse::new);
    }

    public Page<NotificationLogResponse> getAllNotifications(Pageable pageable) {
        return notificationLogRepository.findAll(pageable)
                .map(NotificationLogResponse::new);
    }
}

