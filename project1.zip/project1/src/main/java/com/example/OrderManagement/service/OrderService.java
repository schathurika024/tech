package com.example.OrderManagement.service;

import com.example.OrderManagement.config.RabbitMQConfig;
import com.example.OrderManagement.dto.*;
import com.example.OrderManagement.model.*;
import com.example.OrderManagement.repository.CustomerRepository;
import com.example.OrderManagement.repository.OrderRepository;
import com.example.OrderManagement.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.stream.Collectors;

@Service
public class OrderService {
    private static final Logger logger = LoggerFactory.getLogger(OrderService.class);

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Transactional
    public OrderResponse createOrder(CreateOrderRequest request, Authentication authentication) {
        // Get the authenticated user
        User user = userRepository.findByEmail(authentication.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Get or create customer
        Customer customer;
        if (request.getCustomerId() != null) {
            customer = customerRepository.findById(request.getCustomerId())
                    .orElseThrow(() -> new RuntimeException("Customer not found"));
        } else {
            if (request.getCustomerData() == null) {
                throw new RuntimeException("Customer data is required when customerId is not provided");
            }
            customer = new Customer();
            customer.setName(request.getCustomerData().getName());
            customer.setEmail(request.getCustomerData().getEmail());
            customer.setPhone(request.getCustomerData().getPhone());
            customer = customerRepository.save(customer);
        }

        // Create order
        Order order = new Order();
        order.setCustomer(customer);
        order.setCreatedByUser(user);
        order.setStatus(Order.OrderStatus.NEW);

        // Add items
        for (CreateOrderRequest.OrderItemRequest itemRequest : request.getItems()) {
            OrderItem item = new OrderItem();
            item.setProductName(itemRequest.getProductName());
            item.setQuantity(itemRequest.getQuantity());
            item.setUnitPrice(itemRequest.getUnitPrice());
            order.addItem(item);
        }

        // Calculate total amount
        order.calculateTotalAmount();
        order = orderRepository.save(order);

        // Publish ORDER_CREATED event
        try {
            OrderCreatedEvent event = new OrderCreatedEvent(
                    order.getId(),
                    customer.getEmail(),
                    order.getTotalAmount(),
                    order.getCreatedAt()
            );
            rabbitTemplate.convertAndSend(
                    RabbitMQConfig.EXCHANGE_NAME,
                    RabbitMQConfig.ROUTING_KEY_CREATED,
                    event
            );
            logger.info("Published ORDER_CREATED event for order {}", order.getId());
        } catch (Exception e) {
            logger.error("Failed to publish ORDER_CREATED event", e);
        }

        return new OrderResponse(order);
    }

    @Transactional
    public OrderResponse updateOrderStatus(Long orderId, UpdateOrderStatusRequest request, Authentication authentication) {
        User user = userRepository.findByEmail(authentication.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        // Check authorization: only creator or ADMIN can update
        if (!order.getCreatedByUser().getId().equals(user.getId()) && user.getRole() != User.Role.ADMIN) {
            throw new RuntimeException("You don't have permission to update this order");
        }

        Order.OrderStatus oldStatus = order.getStatus();
        order.setStatus(request.getStatus());
        order.setUpdatedAt(LocalDateTime.now());
        order = orderRepository.save(order);

        // Publish ORDER_STATUS_CHANGED event
        try {
            OrderStatusChangedEvent event = new OrderStatusChangedEvent(
                    order.getId(),
                    oldStatus,
                    order.getStatus(),
                    order.getUpdatedAt()
            );
            rabbitTemplate.convertAndSend(
                    RabbitMQConfig.EXCHANGE_NAME,
                    RabbitMQConfig.ROUTING_KEY_STATUS_CHANGED,
                    event
            );
            logger.info("Published ORDER_STATUS_CHANGED event for order {}", order.getId());
        } catch (Exception e) {
            logger.error("Failed to publish ORDER_STATUS_CHANGED event", e);
        }

        return new OrderResponse(order);
    }

    public OrderResponse getOrderById(Long orderId, Authentication authentication) {
        User user = userRepository.findByEmail(authentication.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        // Check authorization: ADMIN can see any order, USER can see only their own
        if (user.getRole() != User.Role.ADMIN && !order.getCreatedByUser().getId().equals(user.getId())) {
            throw new RuntimeException("You don't have permission to view this order");
        }

        return new OrderResponse(order);
    }

    public Page<OrderResponse> getMyOrders(Authentication authentication, Pageable pageable, Order.OrderStatus status, LocalDateTime startDate, LocalDateTime endDate) {
        User user = userRepository.findByEmail(authentication.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Page<Order> orders;
        if (status != null || startDate != null || endDate != null) {
            orders = orderRepository.findByCreatedByUserWithFilters(
                    user.getId(), status, startDate, endDate, pageable
            );
        } else {
            orders = orderRepository.findByCreatedByUser_Id(user.getId(), pageable);
        }

        return orders.map(OrderResponse::new);
    }
}

