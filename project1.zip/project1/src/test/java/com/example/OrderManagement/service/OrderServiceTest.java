package com.example.OrderManagement.service;

import com.example.OrderManagement.dto.CreateOrderRequest;
import com.example.OrderManagement.dto.OrderCreatedEvent;
import com.example.OrderManagement.dto.OrderResponse;
import com.example.OrderManagement.model.Customer;
import com.example.OrderManagement.model.Order;
import com.example.OrderManagement.model.User;
import com.example.OrderManagement.repository.CustomerRepository;
import com.example.OrderManagement.repository.OrderRepository;
import com.example.OrderManagement.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.security.core.Authentication;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrderServiceTest {
    @Mock
    private OrderRepository orderRepository;

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private RabbitTemplate rabbitTemplate;

    @Mock
    private Authentication authentication;

    @InjectMocks
    private OrderService orderService;

    private User testUser;
    private Customer testCustomer;

    @BeforeEach
    void setUp() {
        testUser = new User();
        testUser.setId(1L);
        testUser.setEmail("user@test.com");
        testUser.setFullName("Test User");
        testUser.setRole(User.Role.USER);

        testCustomer = new Customer();
        testCustomer.setId(1L);
        testCustomer.setName("Test Customer");
        testCustomer.setEmail("customer@test.com");
        testCustomer.setPhone("1234567890");
    }

    @Test
    void testCreateOrderWithNewCustomer() {
        // Arrange
        CreateOrderRequest request = new CreateOrderRequest();
        CreateOrderRequest.CustomerData customerData = new CreateOrderRequest.CustomerData();
        customerData.setName("New Customer");
        customerData.setEmail("newcustomer@test.com");
        customerData.setPhone("9876543210");
        request.setCustomerData(customerData);

        CreateOrderRequest.OrderItemRequest itemRequest = new CreateOrderRequest.OrderItemRequest();
        itemRequest.setProductName("Test Product");
        itemRequest.setQuantity(2);
        itemRequest.setUnitPrice(new BigDecimal("10.00"));
        request.setItems(java.util.Arrays.asList(itemRequest));

        when(authentication.getName()).thenReturn("user@test.com");
        when(userRepository.findByEmail("user@test.com")).thenReturn(Optional.of(testUser));
        when(customerRepository.save(any(Customer.class))).thenReturn(testCustomer);
        when(orderRepository.save(any(Order.class))).thenAnswer(invocation -> {
            Order order = invocation.getArgument(0);
            order.setId(1L);
            return order;
        });

        // Act
        OrderResponse response = orderService.createOrder(request, authentication);

        // Assert
        assertNotNull(response);
        verify(customerRepository, times(1)).save(any(Customer.class));
        verify(orderRepository, times(1)).save(any(Order.class));
        verify(rabbitTemplate, times(1)).convertAndSend(eq("order.events"), eq("order.created"), isA(OrderCreatedEvent.class));
    }

    @Test
    void testCreateOrderWithExistingCustomer() {
        // Arrange
        CreateOrderRequest request = new CreateOrderRequest();
        request.setCustomerId(1L);

        CreateOrderRequest.OrderItemRequest itemRequest = new CreateOrderRequest.OrderItemRequest();
        itemRequest.setProductName("Test Product");
        itemRequest.setQuantity(1);
        itemRequest.setUnitPrice(new BigDecimal("15.00"));
        request.setItems(java.util.Arrays.asList(itemRequest));

        when(authentication.getName()).thenReturn("user@test.com");
        when(userRepository.findByEmail("user@test.com")).thenReturn(Optional.of(testUser));
        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));
        when(orderRepository.save(any(Order.class))).thenAnswer(invocation -> {
            Order order = invocation.getArgument(0);
            order.setId(1L);
            return order;
        });

        // Act
        OrderResponse response = orderService.createOrder(request, authentication);

        // Assert
        assertNotNull(response);
        verify(customerRepository, never()).save(any(Customer.class));
        verify(orderRepository, times(1)).save(any(Order.class));
    }
}

