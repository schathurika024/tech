# OrderFlow - Order Management System

A Spring Boot REST API for managing customer orders with JWT authentication, MySQL database, and RabbitMQ for asynchronous notifications.

## Technology Stack

- **Java**: 21
- **Spring Boot**: 3.5.8
- **Database**: MySQL 8.0
- **Message Broker**: RabbitMQ 3-management
- **Build Tool**: Maven
- **Security**: JWT (JJWT 0.12.3)
- **Containerization**: Docker & Docker Compose

## Prerequisites

- Java 21 or higher
- Maven 3.9+
- Docker and Docker Compose

## How to Build the JAR

```bash
  .\mvnw clean package -DskipTests
```

The JAR file will be created in the `target` directory: `target/OrderManagement-0.0.1-SNAPSHOT.jar`

## How to Build Docker Image

```bash
docker build -t ordermanagement-app .
```

## How to Start Everything

Start all services (application, MySQL, and RabbitMQ) using Docker Compose:

```bash
docker-compose up --build
```

This will start:
- **MySQL** on port `3306`
- **RabbitMQ** on ports `5672` (AMQP) and `15672` (Management UI)
- **MailHog** on ports `1025` (SMTP) and `8025` (Web UI)
- **Spring Boot Application** on port `8080`

Access RabbitMQ Management UI: http://localhost:15672 (username:guest/password:guest)  
Access MailHog Web UI: http://localhost:8025 (for viewing test emails)

## Testing the API

Follow these steps to test the complete flow:

### Step 1: Register a User

```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john.doe@example.com",
    "password": "password123",
    "fullName": "John Doe"
  }'
```

### Step 2: Login and Get JWT Token

```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john.doe@example.com",
    "password": "password123"
  }'
```

**Save the `accessToken` from the response!**

Example response:
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "tokenType": "Bearer",
  "expiresIn": 86400
}
```

### Step 3: Create an Order (Use JWT Token)

Replace `YOUR_TOKEN_HERE` with the token from Step 2:

```bash
curl -X POST http://localhost:8080/api/orders \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{
    "customerData": {
      "name": "Jane Customer",
      "email": "jane@example.com",
      "phone": "1234567890"
    },
    "items": [
      {
        "productName": "Laptop",
        "quantity": 1,
        "unitPrice": 999.99
      },
      {
        "productName": "Mouse",
        "quantity": 2,
        "unitPrice": 29.99
      }
    ]
  }'
```

### Step 4: Register Admin User to View Notifications

```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@example.com",
    "password": "admin123",
    "fullName": "Admin User",
    "role": "ADMIN"
  }'
```

### Step 5: Login as Admin

```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@example.com",
    "password": "admin123"
  }'
```

**Save the admin `accessToken` from the response!**

### Step 6: View Notification Logs

Replace `ADMIN_TOKEN_HERE` with the admin token from Step 5:

```bash
curl -X GET "http://localhost:8080/api/admin/notifications?page=0&size=20" \
  -H "Authorization: Bearer ADMIN_TOKEN_HERE"
```

This will show all notification logs including the ORDER_CREATED event from Step 3.

**Note**: Notification emails are logged to console and can be viewed in MailHog Web UI at http://localhost:8025

## Additional API Endpoints

### Get My Orders
```bash
curl -X GET "http://localhost:8080/api/orders/my?page=0&size=20" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

### Get Order by ID
```bash
curl -X GET "http://localhost:8080/api/orders/1" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

### Update Order Status
```bash
curl -X PATCH http://localhost:8080/api/orders/1/status \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{
    "status": "PROCESSING"
  }'
```

Valid statuses: `NEW`, `PROCESSING`, `COMPLETED`, `CANCELLED`

### Get Current User
```bash
curl -X GET http://localhost:8080/api/users/me \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

## How to view logs

```bash
docker logs ordermanagement-app -f
```

## How to Stop the Application

Press `Ctrl+C` to stop, or run:

```bash
docker-compose down
```


